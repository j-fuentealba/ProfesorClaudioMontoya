var galeria = {
    
  gallery: [
  {
    queue: 1,
    imgPath: "https://nacimiento.cl/~sites/Interfaz/img1.jpg",
    imgDesc: "Imagen 1"
  },
  {
    queue: 2,
    imgPath: "https://nacimiento.cl/~sites/Interfaz/img2.jpg",
    imgDesc: "Imagen 2"
  },
  {
    queue: 3,
    imgPath: "https://nacimiento.cl/~sites/Interfaz/img3.jpg",
    imgDesc: "Imagen 3"
  },
  {
    queue: 4,
    imgPath: "https://nacimiento.cl/~sites/Interfaz/img4.jpg",
    imgDesc: "Imagen 4"
  },
  {
    queue: 5,
    imgPath: "https://nacimiento.cl/~sites/Interfaz/img5.jpg",
    imgDesc: "Imagen 5"
  },
  {
    queue: 6,
    imgPath: "https://nacimiento.cl/~sites/Interfaz/img6.jpg",
    imgDesc: "Imagen 6"
  }
  ]
  
};

console.log(galeria);
/*intial the image show box */

gallery = galeria.gallery;
var currentImgPath, hashchange, direction,
 loading = 'https://yimg.twhouses.com.tw/ynh/public/loading_icon.gif',
 currentImgPoint = 0; 

/* getting the image position if get the hash */
$(window).bind('hashchange', function() {
  hashchange = true;
  //console.log('got the hash!');
  hashPass();
});

if (window.location.hash.length >= 2 ){
  hashchange = true;
  hashPass();
  //console.log('got the hash!');
}
else {
    currentImgPoint = 0;
	imgDisplay()
}

/* process the hash to get the image position */
function hashPass() {
  currentImgPoint = window.location.hash.slice(1);
  hashCheck = currentImgPoint.match(/[0-9]+/g);
  if (hashCheck != currentImgPoint || currentImgPoint >= gallery.length){ 
    //check if the hash is property value
    currentImgPoint = 0;
  }
  imgDisplay();
}

/* update the image */
function imgDisplay() {
  var speed = 800,
  currentImgPath = gallery[currentImgPoint].imgPath;
  //$('#imgeShowBox img').attr('src', currentImgPath);
  $('#imgeShowBox img').attr('src', loading).fadeOut(speed,function(){
    $(this).attr('src',currentImgPath).fadeIn(speed);
  });
  $('#img-desc').text(gallery[currentImgPoint].imgDesc);
  afterImgLoad ();
}

/* callback after refreshing the image */
function afterImgLoad (){
  prevImgPoint = Number(currentImgPoint) - 1;
  nextImgPoint = Number(currentImgPoint) + 1;
  console.log("current " + currentImgPoint);
  console.log("prev " + prevImgPoint);
  console.log("next " + nextImgPoint);
  console.log("direction "+ direction);
  if (prevImgPoint < 0){
    $('#imgAnterior').addClass('disable');
  }
  else {
    $('#imgAnterior').removeClass('disable');
  }
  if (nextImgPoint >= gallery.length){
    $('#imgSiguiente').addClass('disable');
  }
  else {
    $('#imgSiguiente').removeClass('disable');
  }
  hashPoint = '#'+currentImgPoint;
  console.log('hashLocion: ' + hashPoint);
  window.location.hash = hashPoint; //update the hash at the URL
}

/* event click on the previous button */
$('#imgAnterior').click(function(e){
  if (currentImgPoint >= 1) {
    currentImgPoint--;
    direction = 'backward';
   imgDisplay(currentImgPoint);
  }
})

/* event click on the next button */
$('#imgSiguiente').click(function(e){
  if (currentImgPoint < gallery.length -1 ) {
    currentImgPoint++;
    direction = 'forward';
   imgDisplay(currentImgPoint);
  }
})