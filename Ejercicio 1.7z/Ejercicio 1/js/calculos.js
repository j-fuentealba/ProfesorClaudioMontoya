function calcular()
{
    var precio1=document.getElementById("precio").value;
    var cantidad2=document.getElementById("cantidad").value;
    var descuento3=document.getElementById("descuento").value;
    

     descuento3 = descuento3*10;

    if(precio1=="")
    {
    	alert("Ingresa la precio!!");
    	return;
    }
    
     if(cantidad2=="")
    {
    	alert("Ingresa el cantidad!!");
    	return;
    }

    if(descuento3=="")
    {
        alert("Ingresa el descuento!!");
        return;
    }

    var neto=(precio1*cantidad2)-descuento3;
    document.getElementById("neto").value=neto;      


    var iva=neto*0.19;
    document.getElementById("iva").value=iva;

    var total= neto-iva;
    document.getElementById("total").value=total;   

}

function isNumberKey(evt){
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
    return false;
     
    return true;
 }
